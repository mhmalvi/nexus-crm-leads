const express = require("express");
const http = require("http");
const { createConnection } = require("mysql");
const socketIo = require("socket.io");
const bodyParser = require("body-parser");
// var mysql = require("mysql");
const connection = require("./db/db");
const cron = require("node-cron");
const axios = require("axios");
const path = require("path");
const router = require("./src/router/router");
const cors = require("cors");
const { exit } = require("process");

const app = express();
const server = http.createServer(app);

app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "DELETE", "UPDATE", "PUT", "PATCH"],
  })
);

//////////////////////////// socket.io notification start//////////////////////////
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "DELETE", "UPDATE", "PUT", "PATCH"],
  },
});

app.use(bodyParser.json());
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "/index.html"));
});

io.on("connection", (socket) => {
  // console.log("Connected", socket?.id);
  socket.on("message", (msg) => {
    console.log("msg", msg.user_id);

    var time = new Array();
    var id = msg.user_id;
    const socket_notifier = (req, res) => {
      // exit()
      const sql =
        "select * from follow_ups where user_id=? and status=? and delete_status=?";
      connection.query(sql, [id, 1, 1], (err, results) => {
        // console.log(JSON.stringify(results));
        for (let i = 0; i < results.length; i++) {
          const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
          console.log(timezone);
          let today = new Date();
          console.log("today", today);

          var date = new Date(results[i].start);
          date = new Date(date.setHours(date.getHours() - 6));

          console.log("db", date);

          var today_date =
            today.getFullYear() +
            "-" +
            (today.getMonth() + 1) +
            "-" +
            today.getDate();
          var date_from_db =
            date.getFullYear() +
            "-" +
            (date.getMonth() + 1) +
            "-" +
            date.getDate();
          console.log("today_date", today_date);
          console.log("date_from_db", date_from_db);
          if (today_date == date_from_db) {
            if (
              new Date(results[i]) >= today &&
              new Date(results[i]).setMinutes(
                new Date(results[i]).getMinutes() - 10
              ) <= today
            ) {
              time.push(results[i]);
            }
          }
        }
        io.emit("message", time);
      });
    };
    socket_notifier();
  });
});

app.use("/api", router);

//////////////////////////// socket.io notification end//////////////////////////

server.listen(7000, () => {
  console.log("listening");
});
